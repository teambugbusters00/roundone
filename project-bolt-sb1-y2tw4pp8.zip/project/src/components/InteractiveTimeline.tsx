import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, CheckCircle, Clock, ArrowRight } from 'lucide-react';

interface TimelineEvent {
  id: string;
  year: string;
  title: string;
  description: string;
  details: string;
  color: string;
  icon: React.ReactNode;
}

const timelineEvents: TimelineEvent[] = [
  {
    id: '1',
    year: '2020',
    title: 'Foundation',
    description: 'Platform Pro was founded with a vision to revolutionize development.',
    details: 'Started with a small team of passionate developers who believed in making development more accessible and efficient.',
    color: 'from-blue-400 to-blue-600',
    icon: <Calendar className="w-6 h-6" />
  },
  {
    id: '2',
    year: '2021',
    title: 'First Release',
    description: 'Launched our first beta version with core features.',
    details: 'Released with essential development tools, gaining our first 1,000 users and valuable feedback.',
    color: 'from-green-400 to-green-600',
    icon: <CheckCircle className="w-6 h-6" />
  },
  {
    id: '3',
    year: '2022',
    title: 'AI Integration',
    description: 'Introduced AI-powered development assistance.',
    details: 'Revolutionary AI features that helped developers write better code faster, increasing productivity by 40%.',
    color: 'from-purple-400 to-purple-600',
    icon: <Clock className="w-6 h-6" />
  },
  {
    id: '4',
    year: '2023',
    title: 'Global Expansion',
    description: 'Expanded to serve developers worldwide.',
    details: 'Reached 100,000+ users across 150+ countries with localized support and features.',
    color: 'from-orange-400 to-orange-600',
    icon: <ArrowRight className="w-6 h-6" />
  },
  {
    id: '5',
    year: '2024',
    title: 'Enterprise Solutions',
    description: 'Launched enterprise-grade features and security.',
    details: 'Introduced advanced security, compliance features, and enterprise support for large organizations.',
    color: 'from-red-400 to-red-600',
    icon: <CheckCircle className="w-6 h-6" />
  },
  {
    id: '6',
    year: '2025',
    title: 'Future Vision',
    description: 'Continuing to innovate and shape the future of development.',
    details: 'Working on next-generation features including quantum computing integration and advanced AI collaboration.',
    color: 'from-indigo-400 to-indigo-600',
    icon: <Calendar className="w-6 h-6" />
  }
];

export const InteractiveTimeline: React.FC = () => {
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);

  return (
    <section id="timeline" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-4">
            Our Journey
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            From a small startup to a global platform, discover the milestones that shaped our story.
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-600 to-purple-600 rounded-full" />

          <div className="space-y-12">
            {timelineEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`flex items-center ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    onClick={() => setSelectedEvent(selectedEvent === event.id ? null : event.id)}
                    className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer"
                  >
                    <div className={`inline-flex p-3 rounded-xl bg-gradient-to-r ${event.color} text-white mb-4`}>
                      {event.icon}
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      {event.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {event.description}
                    </p>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      className="text-blue-600 dark:text-blue-400 font-medium hover:underline"
                    >
                      Learn More
                    </motion.button>
                  </motion.div>
                </div>

                {/* Timeline Node */}
                <div className="relative z-10">
                  <motion.div
                    whileHover={{ scale: 1.2 }}
                    className={`w-16 h-16 rounded-full bg-gradient-to-r ${event.color} flex items-center justify-center text-white font-bold text-lg shadow-lg`}
                  >
                    {event.year.slice(-2)}
                  </motion.div>
                </div>

                <div className="w-1/2" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Detailed View Modal */}
        <AnimatePresence>
          {selectedEvent && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
              onClick={() => setSelectedEvent(null)}
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white dark:bg-gray-800 rounded-2xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
              >
                {(() => {
                  const event = timelineEvents.find(e => e.id === selectedEvent);
                  if (!event) return null;
                  
                  return (
                    <>
                      <div className={`inline-flex p-4 rounded-xl bg-gradient-to-r ${event.color} text-white mb-6`}>
                        {event.icon}
                      </div>
                      <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                        {event.year} - {event.title}
                      </h3>
                      <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">
                        {event.description}
                      </p>
                      <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                        {event.details}
                      </p>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setSelectedEvent(null)}
                        className="mt-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-medium"
                      >
                        Close
                      </motion.button>
                    </>
                  );
                })()}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};