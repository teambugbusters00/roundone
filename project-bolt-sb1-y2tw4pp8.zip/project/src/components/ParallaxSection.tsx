import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Rocket, Star, Zap } from 'lucide-react';

export const ParallaxSection: React.FC = () => {
  const { scrollYProgress } = useScroll();
  
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, -50]);

  return (
    <section className="relative h-screen overflow-hidden bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      {/* Background Elements */}
      <motion.div
        style={{ y: y1 }}
        className="absolute top-20 left-10 text-blue-300 opacity-20"
      >
        <Rocket className="w-32 h-32" />
      </motion.div>
      
      <motion.div
        style={{ y: y2 }}
        className="absolute top-40 right-20 text-purple-300 opacity-20"
      >
        <Star className="w-24 h-24" />
      </motion.div>
      
      <motion.div
        style={{ y: y3 }}
        className="absolute bottom-20 left-1/4 text-indigo-300 opacity-20"
      >
        <Zap className="w-28 h-28" />
      </motion.div>

      {/* Content */}
      <div className="relative z-10 flex items-center justify-center h-full px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-center text-white max-w-4xl"
        >
          <h2 className="text-5xl md:text-7xl font-bold mb-6">
            Innovation
            <span className="block bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Never Stops
            </span>
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-blue-100">
            We're constantly pushing the boundaries of what's possible in development technology.
          </p>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(255, 255, 255, 0.1)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-white text-blue-900 px-8 py-4 rounded-xl text-lg font-bold hover:bg-blue-50 transition-colors"
          >
            Explore Innovation
          </motion.button>
        </motion.div>
      </div>

      {/* Floating Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-white rounded-full opacity-30"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}
    </section>
  );
};