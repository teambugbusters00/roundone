import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Star, Zap, Crown } from 'lucide-react';

interface PricingTier {
  id: string;
  name: string;
  price: {
    monthly: number;
    yearly: number;
  };
  description: string;
  features: string[];
  limitations: string[];
  popular: boolean;
  icon: React.ReactNode;
  color: string;
}

const pricingTiers: PricingTier[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: { monthly: 0, yearly: 0 },
    description: 'Perfect for individual developers and small projects',
    features: [
      'Up to 3 projects',
      'Basic AI assistance',
      'Community support',
      '5GB storage',
      'Standard templates'
    ],
    limitations: [
      'Limited API calls',
      'No priority support',
      'Basic analytics'
    ],
    popular: false,
    icon: <Star className="w-6 h-6" />,
    color: 'from-gray-400 to-gray-600'
  },
  {
    id: 'pro',
    name: 'Professional',
    price: { monthly: 29, yearly: 290 },
    description: 'Ideal for growing teams and advanced projects',
    features: [
      'Unlimited projects',
      'Advanced AI features',
      'Priority support',
      '100GB storage',
      'Premium templates',
      'Team collaboration',
      'Advanced analytics',
      'Custom integrations'
    ],
    limitations: [],
    popular: true,
    icon: <Zap className="w-6 h-6" />,
    color: 'from-blue-400 to-purple-600'
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: { monthly: 99, yearly: 990 },
    description: 'For large organizations with advanced needs',
    features: [
      'Everything in Pro',
      'Dedicated support',
      'Unlimited storage',
      'Custom AI training',
      'Advanced security',
      'SSO integration',
      'Custom contracts',
      'On-premise deployment'
    ],
    limitations: [],
    popular: false,
    icon: <Crown className="w-6 h-6" />,
    color: 'from-purple-400 to-pink-600'
  }
];

export const PricingTiers: React.FC = () => {
  const [isYearly, setIsYearly] = useState(false);

  return (
    <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-4">
            Choose Your Plan
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Start free and scale as you grow. All plans include our core features with varying limits and support levels.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center mb-12">
            <span className={`mr-3 ${!isYearly ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500'}`}>
              Monthly
            </span>
            <motion.button
              onClick={() => setIsYearly(!isYearly)}
              className={`relative w-14 h-8 rounded-full transition-colors ${
                isYearly ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md"
                animate={{ x: isYearly ? 24 : 0 }}
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              />
            </motion.button>
            <span className={`ml-3 ${isYearly ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500'}`}>
              Yearly
            </span>
            {isYearly && (
              <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                Save 17%
              </span>
            )}
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingTiers.map((tier, index) => (
            <motion.div
              key={tier.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className={`relative bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 ${
                tier.popular ? 'ring-2 ring-blue-600 scale-105' : ''
              }`}
            >
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}

              <div className={`inline-flex p-3 rounded-xl bg-gradient-to-r ${tier.color} text-white mb-4`}>
                {tier.icon}
              </div>

              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                {tier.name}
              </h3>

              <p className="text-gray-600 dark:text-gray-300 mb-6">
                {tier.description}
              </p>

              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">
                  ${isYearly ? tier.price.yearly : tier.price.monthly}
                </span>
                <span className="text-gray-600 dark:text-gray-300 ml-2">
                  /{isYearly ? 'year' : 'month'}
                </span>
                {isYearly && tier.price.monthly > 0 && (
                  <div className="text-sm text-gray-500 mt-1">
                    ${(tier.price.yearly / 12).toFixed(0)}/month billed annually
                  </div>
                )}
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-full py-3 rounded-xl font-medium transition-all duration-300 mb-6 ${
                  tier.popular
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg hover:shadow-xl'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {tier.price.monthly === 0 ? 'Get Started Free' : 'Start Free Trial'}
              </motion.button>

              <div className="space-y-3">
                {tier.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                  </div>
                ))}
                {tier.limitations.map((limitation, limitationIndex) => (
                  <div key={limitationIndex} className="flex items-center opacity-60">
                    <X className="w-5 h-5 text-gray-400 mr-3 flex-shrink-0" />
                    <span className="text-gray-500 dark:text-gray-400">{limitation}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center mt-12"
        >
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Need a custom solution? We offer tailored plans for large enterprises.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="text-blue-600 dark:text-blue-400 font-medium hover:underline"
          >
            Contact Sales
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};