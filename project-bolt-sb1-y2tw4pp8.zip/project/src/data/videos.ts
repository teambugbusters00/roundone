export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  category: string;
}

export const videos: Video[] = [
  {
    id: '1',
    title: 'Modern Web Development',
    description: 'Explore the latest trends and technologies in modern web development, from React to TypeScript.',
    thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
    category: 'Technology'
  },
  {
    id: '2',
    title: 'Creative Design Process',
    description: 'Dive into the creative process behind stunning digital designs and user experiences.',
    thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
    category: 'Design'
  },
  {
    id: '3',
    title: 'Business Innovation',
    description: 'Learn about innovative business strategies that are reshaping industries worldwide.',
    thumbnail: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_5mb.mp4',
    category: 'Business'
  },
  {
    id: '4',
    title: 'AI and Machine Learning',
    description: 'Discover the fascinating world of artificial intelligence and its real-world applications.',
    thumbnail: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
    category: 'Technology'
  },
  {
    id: '5',
    title: 'Sustainable Future',
    description: 'Explore sustainable practices and green technologies that are building a better tomorrow.',
    thumbnail: 'https://images.pexels.com/photos/9800029/pexels-photo-9800029.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
    category: 'Environment'
  },
  {
    id: '6',
    title: 'Digital Marketing Trends',
    description: 'Stay ahead with the latest digital marketing strategies and consumer behavior insights.',
    thumbnail: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=800',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_5mb.mp4',
    category: 'Business'
  }
];

export const categories = ['All', 'Technology', 'Design', 'Business', 'Environment'];